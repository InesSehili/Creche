from django.apps import AppConfig


class EnfantsConfig(AppConfig):
    name = 'enfants'
