from django.apps import AppConfig


class AutorisationsConfig(AppConfig):
    name = 'autorisations'
