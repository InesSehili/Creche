from django.apps import AppConfig


class DepensesConfig(AppConfig):
    name = 'depenses'
