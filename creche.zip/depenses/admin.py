from django.contrib import admin

# Register your models here.
from depenses.models import Depense

admin.site.register(Depense)
