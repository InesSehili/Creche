from django.apps import AppConfig


class CategoriesabonnementConfig(AppConfig):
    name = 'categoriesAbonnement'
