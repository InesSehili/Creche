from django.contrib import admin
from categoriesAbonnement.models import CategorieAbonnement

# Register your models here.
admin.site.register(CategorieAbonnement)
