from django.contrib import admin

# Register your models here.
from parents.models import  Parent

admin.site.register(Parent)
