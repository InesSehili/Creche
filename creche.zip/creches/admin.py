from django.contrib import admin

# Register your models here.
from creches.models import  Creche

admin.site.register(Creche)
