from django.apps import AppConfig


class CrechesConfig(AppConfig):
    name = 'creches'
