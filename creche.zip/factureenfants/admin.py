from django.contrib import admin
from factureenfants.models import FactureEnfant

# Register your models here.
admin.site.register(FactureEnfant)
