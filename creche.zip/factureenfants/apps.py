from django.apps import AppConfig


class FactureenfantsConfig(AppConfig):
    name = 'factureenfants'
