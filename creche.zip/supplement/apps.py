from django.apps import AppConfig


class SupplementConfig(AppConfig):
    name = 'supplement'
