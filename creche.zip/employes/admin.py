from django.contrib import admin
from employes.models import Employes
# Register your models here.
admin.site.register(Employes)
