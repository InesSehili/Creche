from django.apps import AppConfig


class EmployesConfig(AppConfig):
    name = 'employes'
