from django.contrib import admin

# Register your models here.
from factures.models import  Facture

admin.site.register(Facture)
