from django.apps import AppConfig


class FacturesConfig(AppConfig):
    name = 'factures'
