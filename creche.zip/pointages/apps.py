from django.apps import AppConfig


class PointagesConfig(AppConfig):
    name = 'pointages'
