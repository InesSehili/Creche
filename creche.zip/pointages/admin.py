from django.contrib import admin

from pointages.models import    Pointage

admin.site.register(Pointage)
