from django.contrib import admin

# Register your models here.
from prixsortie.models import  Prixsortie

admin.site.register(Prixsortie)
