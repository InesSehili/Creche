from django.apps import AppConfig


class PrixsortieConfig(AppConfig):
    name = 'prixsortie'
