from django.apps import AppConfig


class FactureemployesConfig(AppConfig):
    name = 'factureemployes'
