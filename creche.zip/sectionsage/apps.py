from django.apps import AppConfig


class SectionsageConfig(AppConfig):
    name = 'sectionsage'
