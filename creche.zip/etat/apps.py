from django.apps import AppConfig


class EtatConfig(AppConfig):
    name = 'etat'
