from django.apps import AppConfig


class PayementConfig(AppConfig):
    name = 'payement'
