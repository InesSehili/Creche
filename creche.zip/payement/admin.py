from django.contrib import admin

# Register your models here.
from payement.models import  Payement

admin.site.register(Payement)