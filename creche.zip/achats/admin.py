from django.contrib import admin

# Register your models here.
from achats.models import  Achat

admin.site.register(Achat)

