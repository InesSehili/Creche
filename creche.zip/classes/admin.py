from django.contrib import admin

# Register your models here.
from classes.models import  Classe

admin.site.register(Classe)

