from django.apps import AppConfig


class BesoinConfig(AppConfig):
    name = 'besoin'
