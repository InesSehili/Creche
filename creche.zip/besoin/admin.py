from django.contrib import admin

# Register your models here.
from besoin.models import Besoin 

admin.site.register(Besoin)

