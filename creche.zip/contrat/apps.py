from django.apps import AppConfig


class ContratConfig(AppConfig):
    name = 'contrat'
